---
title: "v7_set_proto()"
decl_name: "v7_set_proto"
symbol_kind: "func"
signature: |
  v7_val_t v7_set_proto(struct v7 *v7, v7_val_t obj, v7_val_t proto);
---

Set object's prototype. Return old prototype or undefined on error. 

