---
title: "v7_mk_object()"
decl_name: "v7_mk_object"
symbol_kind: "func"
signature: |
  v7_val_t v7_mk_object(struct v7 *v7);
---

Make an empty object 

