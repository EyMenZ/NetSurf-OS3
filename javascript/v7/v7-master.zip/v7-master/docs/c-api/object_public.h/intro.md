---
title: "Objects"
symbol_kind: "intro"
decl_name: "object_public.h"
---



