---
title: "Strings"
symbol_kind: "intro"
decl_name: "string_public.h"
---



