---
title: "v7_mk_undefined()"
decl_name: "v7_mk_undefined"
symbol_kind: "func"
signature: |
  v7_val_t v7_mk_undefined(void);
---

Make `undefined` primitive value 

