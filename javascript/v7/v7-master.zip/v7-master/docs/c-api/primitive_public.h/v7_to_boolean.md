---
title: "v7_to_boolean()"
decl_name: "v7_to_boolean"
symbol_kind: "func"
signature: |
  int v7_to_boolean(v7_val_t v);
---

Returns boolean stored in `v7_val_t`:
 0 for `false` or non-boolean, non-0 for `true` 

