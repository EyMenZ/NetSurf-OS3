---
title: "v7_mk_null()"
decl_name: "v7_mk_null"
symbol_kind: "func"
signature: |
  v7_val_t v7_mk_null(void);
---

Make `null` primitive value 

