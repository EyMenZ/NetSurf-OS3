---
title: "v7_to_foreign()"
decl_name: "v7_to_foreign"
symbol_kind: "func"
signature: |
  void *v7_to_foreign(v7_val_t v);
---

Returns `void *` pointer stored in `v7_val_t`.

Returns NULL if the value is not a foreign pointer. 

