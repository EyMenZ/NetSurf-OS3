---
title: "v7_to_number()"
decl_name: "v7_to_number"
symbol_kind: "func"
signature: |
  double v7_to_number(v7_val_t v);
---

Returns `double` value stored in `v7_val_t`.

Returns NaN for non-numbers. 

