---
title: "v7_is_undefined()"
decl_name: "v7_is_undefined"
symbol_kind: "func"
signature: |
  int v7_is_undefined(v7_val_t v);
---

Returns true if given value is a primitive `undefined` value 

