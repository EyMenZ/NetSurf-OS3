---
title: "Primitives"
symbol_kind: "intro"
decl_name: "primitive_public.h"
---

All primitive values but strings.

"foreign" values are also here, see `v7_mk_foreign()`.

