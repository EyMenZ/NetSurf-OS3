---
title: "RegExp"
symbol_kind: "intro"
decl_name: "regexp_public.h"
---



