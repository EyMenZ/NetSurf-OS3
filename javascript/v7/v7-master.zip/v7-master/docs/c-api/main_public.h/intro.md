---
title: "v7 main()"
symbol_kind: "intro"
decl_name: "main_public.h"
---



