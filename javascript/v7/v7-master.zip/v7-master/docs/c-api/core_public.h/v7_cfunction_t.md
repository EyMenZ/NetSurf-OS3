---
title: "v7_cfunction_t"
decl_name: "v7_cfunction_t"
symbol_kind: "typedef"
signature: |
  typedef enum v7_err(v7_cfunction_t)(struct v7 *v7, v7_val_t *res);
---

JavaScript -> C call interface 

