---
title: "v7_create()"
decl_name: "v7_create"
symbol_kind: "func"
signature: |
  struct v7 *v7_create(void);
---

Create V7 instance 

