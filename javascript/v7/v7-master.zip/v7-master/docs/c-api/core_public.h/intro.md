---
title: "Core"
symbol_kind: "intro"
decl_name: "core_public.h"
---



