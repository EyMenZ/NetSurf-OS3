---
title: "v7_arg()"
decl_name: "v7_arg"
symbol_kind: "func"
signature: |
  v7_val_t v7_arg(struct v7 *v, unsigned long i);
---

Return i-th argument 

