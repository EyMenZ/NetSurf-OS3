---
title: "v7_get_global()"
decl_name: "v7_get_global"
symbol_kind: "func"
signature: |
  v7_val_t v7_get_global(struct v7 *v);
---

Return root level (`global`) object of the given V7 instance. 

