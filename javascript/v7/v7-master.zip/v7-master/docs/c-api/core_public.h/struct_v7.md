---
title: "struct v7"
decl_name: "struct v7"
symbol_kind: "struct"
signature: |
  struct v7 {
    /* ... */
  };
---

Opaque structure. V7 engine context. 

