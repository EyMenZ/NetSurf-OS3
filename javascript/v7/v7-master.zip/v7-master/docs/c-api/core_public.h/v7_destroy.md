---
title: "v7_destroy()"
decl_name: "v7_destroy"
symbol_kind: "func"
signature: |
  void v7_destroy(struct v7 *v7);
---

Destroy V7 instance 

