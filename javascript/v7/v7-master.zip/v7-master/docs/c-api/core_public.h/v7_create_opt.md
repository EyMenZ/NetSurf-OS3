---
title: "v7_create_opt()"
decl_name: "v7_create_opt"
symbol_kind: "func"
signature: |
  struct v7 *v7_create_opt(struct v7_create_opts opts);
---

Like `v7_create()`, but allows to customize initial v7 state, see `struct
v7_create_opts`. 

