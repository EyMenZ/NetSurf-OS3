---
title: "Arrays"
symbol_kind: "intro"
decl_name: "array_public.h"
---



