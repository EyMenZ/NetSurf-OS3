---
title: "v7_is_array()"
decl_name: "v7_is_array"
symbol_kind: "func"
signature: |
  int v7_is_array(struct v7 *v7, v7_val_t v);
---

Returns true if given value is an array object 

