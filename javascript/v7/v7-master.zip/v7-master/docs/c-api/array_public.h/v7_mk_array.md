---
title: "v7_mk_array()"
decl_name: "v7_mk_array"
symbol_kind: "func"
signature: |
  v7_val_t v7_mk_array(struct v7 *v7);
---

Make an empty array object 

