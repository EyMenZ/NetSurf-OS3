---
title: "v7_array_length()"
decl_name: "v7_array_length"
symbol_kind: "func"
signature: |
  unsigned long v7_array_length(struct v7 *v7, v7_val_t arr);
---

Returns length on an array. If `arr` is not an array, 0 is returned. 

