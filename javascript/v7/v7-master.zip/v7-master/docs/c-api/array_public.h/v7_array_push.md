---
title: "v7_array_push()"
decl_name: "v7_array_push"
symbol_kind: "func"
signature: |
  int v7_array_push(struct v7 *, v7_val_t arr, v7_val_t v);
---

Insert value `v` in array `arr` at the end of the array. 

