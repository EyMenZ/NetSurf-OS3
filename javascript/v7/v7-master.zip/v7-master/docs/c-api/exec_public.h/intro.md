---
title: "Execution of JavaScript code"
symbol_kind: "intro"
decl_name: "exec_public.h"
---



