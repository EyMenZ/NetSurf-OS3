---
title: "v7_clear_thrown_value()"
decl_name: "v7_clear_thrown_value"
symbol_kind: "func"
signature: |
  void v7_clear_thrown_value(struct v7 *v7);
---

Clears currently thrown value, if any. 

