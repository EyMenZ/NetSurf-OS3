---
title: "Exceptions"
symbol_kind: "intro"
decl_name: "exceptions_public.h"
---



