---
title: "Functions"
symbol_kind: "intro"
decl_name: "function_public.h"
---



