---
title: "v7_to_json()"
decl_name: "v7_to_json"
symbol_kind: "func"
signature: |
  #define v7_to_json(a, b, c, d);
---

A shortcut for `v7_stringify()` with `V7_STRINGIFY_JSON` 

