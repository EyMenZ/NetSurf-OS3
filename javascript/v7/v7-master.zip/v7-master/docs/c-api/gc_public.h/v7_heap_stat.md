---
title: "v7_heap_stat()"
decl_name: "v7_heap_stat"
symbol_kind: "func"
signature: |
  int v7_heap_stat(struct v7 *v7, enum v7_heap_stat_what what);
---

Returns a given heap statistics 

