---
title: "Garbage Collector"
symbol_kind: "intro"
decl_name: "gc_public.h"
---



