---
title: "Utility functions"
symbol_kind: "intro"
decl_name: "util_public.h"
---



