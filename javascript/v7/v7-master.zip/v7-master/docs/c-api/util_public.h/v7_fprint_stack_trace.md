---
title: "v7_fprint_stack_trace()"
decl_name: "v7_fprint_stack_trace"
symbol_kind: "func"
signature: |
  void v7_fprint_stack_trace(FILE *f, struct v7 *v7, v7_val_t e);
---

Output stack trace recorded in the exception `e` to file `f` 

