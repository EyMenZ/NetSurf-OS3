---
title: "v7_print_error()"
decl_name: "v7_print_error"
symbol_kind: "func"
signature: |
  void v7_print_error(FILE *f, struct v7 *v7, const char *ctx, v7_val_t e);
---

Output error object message and possibly stack trace to f 

