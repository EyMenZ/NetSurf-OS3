---
title: Crypto.base64_encode()
signature: |
  Crypto.base64_encode(str)
---

Base64-encode input string `str` and return encoded string.
