---
title: File.remove()
signature: |
  File.remove(file_name) -> errno
---

Delete file `file_name`.

Return 0 on success, or `errno` value on error.
