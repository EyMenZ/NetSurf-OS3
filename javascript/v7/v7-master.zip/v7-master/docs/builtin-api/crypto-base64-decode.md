---
title: Crypto.base64_decode()
signature: |
  Crypto.base64_decode(str)
---

Base64-decode input string `str` and return decoded string.
