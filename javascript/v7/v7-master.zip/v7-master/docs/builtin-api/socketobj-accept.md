---
title: socket_obj.accept()
signature: |
  socket_obj.accept() -> socket_obj
---

Sleep until new incoming connection is arrived. Return accepted socket object
on success, or `null` on error.
