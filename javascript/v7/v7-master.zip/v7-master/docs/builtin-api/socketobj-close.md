---
title: socket_obj.close()
signature: |
  socket_obj.close() -> numeric_errno
---

Close socket object. Return 0 on success, or system errno on error.
