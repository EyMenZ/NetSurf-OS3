---
title: socket_obj.recvAll()
signature: |
  socket_obj.recvAll() -> string
---

Same as `recv()`, but keeps reading data until socket is closed.
