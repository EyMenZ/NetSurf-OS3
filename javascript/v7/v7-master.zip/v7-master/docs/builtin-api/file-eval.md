---
title: File.eval()
signature: |
  File.eval(file_name)
---

Parse and run `file_name`.

Throws an exception if the file doesn't exist, cannot be parsed or if the
script throws any exception.
