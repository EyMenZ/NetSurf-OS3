---
title: socket_obj.recv()
signature: |
  socket_obj.recv() -> string
---

Read data from socket. Return data string, or empty string if peer has
disconnected, or `null` on error.
