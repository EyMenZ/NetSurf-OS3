---
title: File.rename()
signature: |
  File.rename(old_name, new_name) -> errno
---

Rename file `old_name` to `new_name`. Return 0 on success, or `errno` value on
error.
