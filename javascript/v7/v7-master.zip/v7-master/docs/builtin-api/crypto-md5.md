---
title: Crypto.md5()
signature: |
  Crypto.md5(str)
  Crypto.md5_hex(str)
---

Generate MD5 hash from input string `str`. Return 16-byte hash (`md5()`), or
stringified hexadecimal representation of the hash (`md5_hex`).
