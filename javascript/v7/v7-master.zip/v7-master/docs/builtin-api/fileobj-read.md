---
title: file_obj.read()
signature: |
  file_obj.read() -> string
---

Read portion of data from an opened file stream. Return string with data, or
an empty string on EOF or error.
