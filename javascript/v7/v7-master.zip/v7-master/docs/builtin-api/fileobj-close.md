---
title: file_obj.close()
signature: |
  file_obj.close() -> undefined
---

Close opened file object.

NOTE: it is user's responsibility to close all opened file streams. V7 does not
do that automatically.
