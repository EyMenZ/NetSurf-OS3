---
title: file_obj.write()
signature: |
  file_obj.write(str) -> num_bytes_written
---

Write string `str` to the opened file object. Return number of bytes written.
