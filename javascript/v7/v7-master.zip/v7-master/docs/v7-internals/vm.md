---
title: VM
---

The VM operates on several core data structures:

- `struct v7` - describes V7 instance itself
- `struct v7_object`, `struct v7_property` - describes object and their
   properties
- `struct ast` - describes AST, which VM executes
