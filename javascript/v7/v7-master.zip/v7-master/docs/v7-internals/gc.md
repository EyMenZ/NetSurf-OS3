---
title: Garbage Collector
---

GC, and other memory optimization techniques, are described in
[V7 memory optimization tech talk](https://docs.cesanta.com/media/slides-v7_mem.html).
