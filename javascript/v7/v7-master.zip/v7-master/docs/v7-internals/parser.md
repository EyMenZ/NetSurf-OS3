---
title: Parser
---

V7 parser is a hand-written recursive-descent parser. It calls tokenizer
to get the next token in the stream, and generates an abstract syntax tree
(AST) that is represented as contiguous chunk of memory.
